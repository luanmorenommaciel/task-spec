#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import json,sys,tempfile,types
sys.path.insert(0,str(Path(sys.argv[1])/'tests/evals/toolkit'))
from record import append_event,read_events,measurement,run_command
from unittest.mock import patch
import run_schedule
from providers import observed_version
with patch('providers.subprocess.check_output',return_value='2.1.272 (Claude Code)\n') as probe:
 assert observed_version('claude','2.1.272')=='2.1.272 (Claude Code)'
 probe.assert_called_once_with(['claude','--version'],text=True,stderr=-2,timeout=10)
with patch('providers.subprocess.check_output',return_value='codex-cli 0.154.0\n'):
 assert observed_version('codex','0.154.0')=='codex-cli 0.154.0'
for actual in ('2.1.273 (Claude Code)','unrecognized output'):
 with patch('providers.subprocess.check_output',return_value=actual):
  try:observed_version('claude','2.1.272')
  except ValueError:pass
  else:raise AssertionError('unregistered harness version accepted')
with patch('providers.subprocess.check_output') as probe:
 try:observed_version('claude',None)
 except ValueError:pass
 else:raise AssertionError('missing version registration accepted')
 probe.assert_not_called()
with tempfile.TemporaryDirectory(prefix='pilot journal ') as temp:
 root=Path(temp);journal=root/'events.jsonl'
 append_event(journal,'run','run_started',{'intervention_recording_enabled':True})
 append_event(journal,'run','intervention_started',{'intervention_id':'decision','actor_kind':'human'})
 try:measurement(read_events(journal),'run')
 except ValueError:pass
 else:raise AssertionError('unfinished run measured')
 append_event(journal,'run','intervention_finished',{'intervention_id':'decision'})
 result=run_command(journal,'run','failing-tool',[sys.executable,'-c','print("retained failure"); raise SystemExit(3)'],root,root/'evidence',10)
 assert result['data']['exit_code']==3
 assert (root/'evidence/failing-tool.stdout').read_text()=='retained failure\n'
 append_event(journal,'run','run_finished',{'accepted':False})
 result=measurement(read_events(journal),'run')
 assert result['censored'] and result['accepted_capability_seconds'] is None and result['intervention_count']==1
 assert result['engineer_active_seconds']>=0 and result['elapsed_seconds']>0
 raw=journal.read_bytes();journal.write_bytes(raw.replace(b'retained failure',b'changed failure'))
 # A real retained event change, not an unchanged search/replace, must fail.
 changed=raw.replace(b'"exit_code":3',b'"exit_code":0');assert changed!=raw;journal.write_bytes(changed)
 try:read_events(journal)
 except ValueError:pass
 else:raise AssertionError('tampered journal verified')
 # A recovery cohort must stop before dispatch when the operator records PAUSE.
 # Retained evidence from a different cohort must remain untouched.
 cohort=root/'corrected cohort';cohort.mkdir()
 previous=root/'initial';previous.mkdir();(previous/'result.json').write_text('{"accepted":false}')
 schedule={'status':'frozen','tooling_directory':'unused','controller_digests':{},
           'runs':[{'id':'not-dispatched','block':1}],'seamwise_executable':'unused'}
 (cohort/'schedule.json').write_text(json.dumps(schedule));(cohort/'PAUSE').write_text('Review the observed permission denial.')
 with patch.object(sys,'argv',['run_schedule.py','--pilot-dir',str(cohort)]), patch.object(run_schedule.subprocess,'run') as dispatch:
  assert run_schedule.main()==2
  dispatch.assert_not_called()
 assert (previous/'result.json').read_text()=='{"accepted":false}'
 assert not (cohort/'results.json').exists(), 'paused work was presented as a completed cohort'
 # A completed block reporting a denial must pause before any following block.
 (cohort/'PAUSE').unlink()
 schedule['runs']=[{'id':f'{block}-{harness}','block':block,'scenario':'small-fix',
                    'harness':harness,'workflow':'integrated','repeat':block}
                   for block in (1,2) for harness in ('codex','claude')]
 (cohort/'schedule.json').write_text(json.dumps(schedule))
 def denied_cell(command,stdout,**kwargs):
  json.dump({'run_id':'denied-cell','accepted':False,'error':'permission denied',
             'elapsed_seconds':1,'cost_including_failures':0,
             'reported_permission_denials':[{'tool_name':'Write'}]},stdout)
  return types.SimpleNamespace(returncode=0)
 with patch.object(sys,'argv',['run_schedule.py','--pilot-dir',str(cohort)]), patch.object(run_schedule.subprocess,'run',side_effect=denied_cell) as dispatch:
  assert run_schedule.main()==2
  assert dispatch.call_count==2, 'a later block ran after the reported denial'
 assert (cohort/'PAUSE').exists()
 assert not (cohort/'results.json').exists()
 # Stop an existing invocation on a native tool denial even if it ignores TERM
 # and never emits the final provider result. Do not classify eval failures so.
 event=json.dumps({'type':'user','message':{'content':[{'type':'tool_result','is_error':True,'content':'--restricted confines the file tools to the working directory'}]}})
 marker=root/'fallback'
 script='import signal,time; from pathlib import Path; signal.signal(signal.SIGTERM,signal.SIG_IGN); print('+repr(event)+',flush=True); time.sleep(2); Path('+repr(str(marker))+').write_text("fallback")'
 stopped=run_command(root/'guard-events.jsonl','guard','denial',[sys.executable,'-c',script],root,root/'guard-output',5,stop_on_denial=True)
 assert stopped['data']['reported_permission_denial'] and stopped['data']['exit_code']!=0
 assert not marker.exists(), 'fallback executed after native permission denial'
 ordinary=run_command(root/'guard-events.jsonl','guard','eval',[sys.executable,'-c','print("AssertionError: expected behavior"); raise SystemExit(1)'],root,root/'guard-output',5,stop_on_denial=True)
 assert ordinary['data']['exit_code']==1 and not ordinary['data']['reported_permission_denial']
print('TOOLKIT_PILOT_RECORDING=PASS prospective intervals, censored failures, retained outputs, tamper detection, cohort pause')
PY
