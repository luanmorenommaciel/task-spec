#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
python3 - "$ROOT" <<'PY'
import json,os,re,subprocess,sys,tempfile
from pathlib import Path
root=Path(sys.argv[1]);cli=root/'bin/taskspec';registry=json.loads((root/'src/cli/commands.json').read_text())
context=json.loads(subprocess.check_output(['bash',str(cli),'agent-context'],text=True));assert context['commands']==registry;assert {'task_plan_snapshot','task_execution_recipe','task_operational_evidence'} <= context['contracts'].keys()
source=cli.read_text()
for command in {key.split()[0] for key in registry}:
 assert re.search(r'\b'+re.escape(command)+r'(?:\||\))',source),command
 for args in [['help',command],['--json','help',command]]:
  p=subprocess.run(['bash',str(cli),*args],capture_output=True,text=True,timeout=5);assert p.returncode==0,(args,p.stderr)
  if '--json' in args:assert json.loads(p.stdout)['ok'] and '\x1b' not in p.stdout
for shell in ['bash','zsh','fish']:
 completion=subprocess.check_output(['bash',str(cli),'completion',shell],text=True)
 assert all(word in completion for word in ['decompose','recipe','--initiative' if shell!='fish' else 'initiative','review','prepare'])
 if shell=='bash':
  subprocess.run(['/bin/bash','-n'],input=completion,text=True,check=True)
  script=completion+'\nCOMP_WORDS=(taskspec --json decompose prepare sample --r); COMP_CWORD=5; _taskspec_complete; printf "%s\\n" "${COMPREPLY[@]}"\n'
  result=subprocess.check_output(['/bin/bash'],input=script,text=True);assert '--recipe' in result and '--replace' in result,result
for args in [['decompose','review','example'],['decompose','init','../bad','--intent-file','-'],['recipe','validate','/does-not-exist']]:
 p=subprocess.run(['bash',str(cli),'--json',*args],input='',text=True,capture_output=True,timeout=5);assert p.returncode!=0;assert json.loads(p.stdout)['ok'] is False
with tempfile.TemporaryDirectory(prefix='CLI output ') as temp:
 path=Path(temp)/'recipe file.json'
 subprocess.run(['bash',str(cli),'example','recipe','--out',str(path)],check=True,capture_output=True)
 assert subprocess.run(['bash',str(cli),'recipe','validate',str(path)],capture_output=True).returncode==0
print('TOOLKIT_CLI=PASS')
PY
