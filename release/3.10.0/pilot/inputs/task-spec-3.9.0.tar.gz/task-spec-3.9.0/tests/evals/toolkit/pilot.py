#!/usr/bin/env python3
"""Compare measured pilot runs and refuse missing or unmatched evidence."""
import json
import math
from pathlib import Path
import statistics
import sys

SCENARIOS={'small-fix','cross-seam','investigation','contention','incident','release-evidence'}
WORKFLOWS={'separate-engine','integrated','native-harness'}
HARNESS={'codex','claude'}
def evaluate(data):
    rows=data.get('runs',[]);gaps=[]
    if not isinstance(rows,list):return {'contract':'TaskToolkitPilot/v1','qualified':False,'state':'incomplete','gaps':['runs must be a list']}
    identities=set()
    for index,row in enumerate(rows):
        if not isinstance(row,dict):
            return {'contract':'TaskToolkitPilot/v1','qualified':False,'state':'incomplete','gaps':[f'run {index}: must be an object']}
        if row.get('scenario') not in SCENARIOS or row.get('workflow') not in WORKFLOWS or row.get('harness') not in HARNESS:gaps.append(f'run {index}: unknown comparison dimension')
        identity=(row.get('scenario'),row.get('harness'),row.get('workflow'),str(row.get('repeat')))
        if type(row.get('repeat')) is not int or row['repeat']<1 or identity in identities:gaps.append(f'run {index}: missing or duplicate positive repeat identifier')
        identities.add(identity)
        for field in ('model','provider','harness_version','strategy_version','failed_attempts_retained'):
            if not row.get(field):gaps.append(f'run {index}: missing {field}')
    for scenario in sorted(SCENARIOS):
        for harness in sorted(HARNESS):
            group=[r for r in rows if r.get('scenario')==scenario and r.get('harness')==harness]
            for workflow in sorted(WORKFLOWS):
                subset=[r for r in group if r.get('workflow')==workflow]
                if len(subset)<2:gaps.append(f'{scenario}/{harness}/{workflow}: needs at least two repeats')
            repeats=[{r.get('repeat') for r in group if r.get('workflow')==w and type(r.get('repeat')) is int} for w in sorted(WORKFLOWS)]
            if any(value!=repeats[0] for value in repeats[1:]):gaps.append(f'{scenario}/{harness}: unmatched repeats')
            for field in ['repository_snapshot','budget','permissions_digest','evaluator_digest']:
                if not group or any(r.get(field) is None for r in group) or len({json.dumps(r.get(field),sort_keys=True) for r in group})!=1:gaps.append(f'{scenario}/{harness}: unmatched {field}')
    metrics=['engineer_active_seconds','accepted_capability_seconds','cost_including_failures','integration_failures','replanning_churn','false_acceptances','acceptance_correctness']
    for index,row in enumerate(rows):
        for field in metrics:
            if type(row.get(field)) not in (int,float) or not math.isfinite(row[field]) or row[field]<0:gaps.append(f'run {index}: missing measured {field}')
        if isinstance(row.get('acceptance_correctness'),(int,float)) and row['acceptance_correctness']>1:gaps.append(f'run {index}: acceptance correctness must be in [0,1]')
        if not row.get('evidence_refs'):gaps.append(f'run {index}: missing raw evidence')
    if gaps:return {'contract':'TaskToolkitPilot/v1','qualified':False,'state':'incomplete','gaps':gaps}
    summary={w:{m:statistics.median([r[m] for r in rows if r['workflow']==w]) for m in metrics} for w in WORKFLOWS}
    integrated=summary['integrated'];separate=summary['separate-engine']
    times=['engineer_active_seconds','accepted_capability_seconds']
    improves=all(integrated[t]<=separate[t] for t in times) and any(integrated[t]<separate[t] for t in times)
    no_false=all(r['false_acceptances']==0 for r in rows)
    quality=all(statistics.mean(r['acceptance_correctness'] for r in rows if r['scenario']==s and r['harness']==h and r['workflow']=='integrated')>=statistics.mean(r['acceptance_correctness'] for r in rows if r['scenario']==s and r['harness']==h and r['workflow']=='separate-engine') for s in SCENARIOS for h in HARNESS)
    return {'contract':'TaskToolkitPilot/v1','qualified':no_false and quality and improves,'state':'evaluated','no_false_acceptance':no_false,'quality_nonregression':quality,'productivity_improved':improves,'medians':summary,'gaps':[]}
if __name__=='__main__':
    if len(sys.argv)!=3 or sys.argv[1]!='validate':raise SystemExit('Usage: pilot.py validate <results.json>')
    result=evaluate(json.loads(Path(sys.argv[2]).read_text()));print(json.dumps(result,indent=2));raise SystemExit(0 if result['qualified'] else 1)
