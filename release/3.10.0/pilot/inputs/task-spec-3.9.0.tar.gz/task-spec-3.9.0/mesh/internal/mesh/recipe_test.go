package mesh

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func recipeStore(t *testing.T) (*Store, Lease) {
	t.Helper()
	root := t.TempDir()
	if out, err := exec.Command("git", "init", "-q", root).CombinedOutput(); err != nil {
		t.Fatalf("git: %v %s", err, out)
	}
	repo, err := ResolveRepository(root)
	if err != nil {
		t.Fatal(err)
	}
	store, err := OpenStore(repo)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { store.Close() })
	now := NowUTC()
	expiry := time.Now().UTC().Add(time.Hour).Format(time.RFC3339)
	_, err = store.db.Exec("INSERT INTO runs(run_id,graph_revision_digest,target_branch,target_commit,integration_branch,mode,max_parallel,state,created_at) VALUES ('run','graph','main','base','int','supervised',1,'active',?)", now)
	if err != nil {
		t.Fatal(err)
	}
	_, err = store.db.Exec("INSERT INTO leases(attempt_id,run_id,task_id,task_revision_digest,fencing_token,owner,issued_at,expires_at,heartbeat_at,state) VALUES ('attempt','run','task','revision',1,'test',?,?,?,'running')", now, expiry, now)
	if err != nil {
		t.Fatal(err)
	}
	return store, Lease{RunID: "run", TaskID: "task", TaskRevisionDigest: "revision", AttemptID: "attempt", FencingToken: 1, Workspace: root}
}

func TestRecipeBudgetPersistsAcrossReplacement(t *testing.T) {
	store, lease := recipeStore(t)
	recipe := &executionRecipe{MaxRounds: 3, NoProgress: 2}
	n, deadline, err := store.reserveRecipeRound(lease, recipe, 30)
	if err != nil || n != 1 {
		t.Fatalf("first: %d %v", n, err)
	}
	// A different attempt of the same revision consumes the same durable budget.
	_, err = store.db.Exec("UPDATE leases SET attempt_id='replacement',fencing_token=2 WHERE attempt_id='attempt'")
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err = store.reserveRecipeRound(lease, recipe, 30); err == nil {
		t.Fatal("stale attempt reserved a round")
	}
	lease.AttemptID = "replacement"
	lease.FencingToken = 2
	n, same, err := store.reserveRecipeRound(lease, recipe, 30)
	if err != nil || n != 2 || !same.Equal(deadline) {
		t.Fatalf("resume reset budget/deadline: %d %v", n, err)
	}
	if _, _, err = store.reserveRecipeRound(lease, recipe, 30); err != nil {
		t.Fatal(err)
	}
	if _, _, err = store.reserveRecipeRound(lease, recipe, 30); err == nil || !strings.Contains(err.Error(), "EXHAUSTED") {
		t.Fatalf("budget not enforced: %v", err)
	}
}

func TestRecipeNoProgressAndFencing(t *testing.T) {
	store, lease := recipeStore(t)
	recipe := &executionRecipe{MaxRounds: 5, NoProgress: 2}
	if _, _, err := store.reserveRecipeRound(lease, recipe, 30); err != nil {
		t.Fatal(err)
	}
	for _, fingerprint := range []string{"eval_1:digest-a", "eval_1:digest-b", "eval_1:digest-b"} {
		if _, err := store.recordRecipeFailure(lease, fingerprint); err != nil {
			t.Fatal(err)
		}
	}
	if _, _, err := store.reserveRecipeRound(lease, recipe, 30); err == nil || !strings.Contains(err.Error(), "NO_PROGRESS") {
		t.Fatalf("breaker: %v", err)
	}
	if _, err := store.db.Exec("UPDATE leases SET state='cancelled'"); err != nil {
		t.Fatal(err)
	}
	if _, err := store.recordRecipeFailure(lease, "new"); err == nil {
		t.Fatal("cancelled attempt changed failure accounting")
	}
}

func TestRecipeTotalTimeoutAndCancellation(t *testing.T) {
	store, lease := recipeStore(t)
	recipe := &executionRecipe{MaxRounds: 3, NoProgress: 2}
	if _, _, err := store.reserveRecipeRound(lease, recipe, 30); err != nil {
		t.Fatal(err)
	}
	if _, err := store.db.Exec("UPDATE recipe_budgets SET deadline=?", time.Now().Add(-time.Second).UTC().Format(time.RFC3339Nano)); err != nil {
		t.Fatal(err)
	}
	if _, _, err := store.reserveRecipeRound(lease, recipe, 30); err == nil || !strings.Contains(err.Error(), "TIMEOUT") {
		t.Fatal("timeout reset")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := managedCommand(ctx, lease.Workspace, "sh", []string{"-c", "sleep 5"}, "", os.Environ()); err == nil {
		t.Fatal("cancelled command ran")
	}
}

func TestRecipeRefusesRequiredCapabilityBeforeInvocation(t *testing.T) {
	store, lease := recipeStore(t)
	handoff := recipeHandoff{}
	handoff.Agent.Timeout = 30
	handoff.Agent.Recipe = &executionRecipe{Contract: "TaskExecutionRecipe/v1", MaxRounds: 3, NoProgress: 2, Required: []string{"managed_recipe_v1", "hard_token_budget"}}
	err := store.executeManagedRecipe(context.Background(), lease, AdapterDefinition{}, AdapterProbe{}, "", "", handoff)
	if err == nil || !strings.Contains(err.Error(), "RECIPE_CAPABILITY_UNAVAILABLE") {
		t.Fatalf("missing capability ran: %v", err)
	}
	var count int
	if err = store.db.QueryRow("SELECT COUNT(*) FROM recipe_budgets").Scan(&count); err != nil || count != 0 {
		t.Fatalf("unsupported capability consumed a round: %d %v", count, err)
	}
}

func TestRecipeIdentityPreservesUnknownAndReportedValues(t *testing.T) {
	unknown := recipeIdentity("", "", "")
	if unknown["model"] != nil || unknown["provider"] != nil {
		t.Fatal("inferred unreported model/provider")
	}
	reported := recipeIdentity("{\"model\":\"reported-model\"}\n{\"modelUsage\":{\"helper-model\":{}}}", "chosen-model", "chosen-provider")
	if reported["model"] != "chosen-model" || reported["provider"] != "chosen-provider" || len(reported["reported_models"].([]string)) != 2 {
		t.Fatal(reported)
	}
}

func TestManagedClaudeLoadsOnlyDeclaredMCPContext(t *testing.T) {
	definition := AdapterDefinition{Name: "claude-native"}
	handoff := recipeHandoff{}
	if !contains(managedAdapterArguments(definition, handoff, []string{"-p"}), "--strict-mcp-config") {
		t.Fatal("undeclared global MCP configuration loaded")
	}
	if !contains(managedAdapterArguments(definition, handoff, []string{"-p"}), "--restricted") {
		t.Fatal("undeclared user hooks loaded")
	}
	handoff.Agent.MCPDependencies = []string{"declared-server"}
	if contains(managedAdapterArguments(definition, handoff, []string{"-p"}), "--strict-mcp-config") {
		t.Fatal("declared MCP dependencies discarded")
	}
}

func TestRecipeEvalEvidenceAndScope(t *testing.T) {
	failures, err := failingRecipeEvals("{\"eval\":\"eval_1\",\"status\":\"fail\"}\n{\"eval\":\"_exit_check\",\"status\":\"pass\"}", []string{"eval_1"})
	if err != nil || len(failures) != 1 {
		t.Fatalf("eval result %v %v", failures, err)
	}
	if _, err = failingRecipeEvals("", []string{"eval_1"}); err == nil {
		t.Fatal("missing eval evidence accepted")
	}
	_, lease := recipeStore(t)
	for _, args := range [][]string{{"config", "user.email", "fixture@example.invalid"}, {"config", "user.name", "fixture"}, {"commit", "--allow-empty", "-qm", "fixture"}} {
		cmd := exec.Command("git", args...)
		cmd.Dir = lease.Workspace
		if err := cmd.Run(); err != nil {
			t.Fatal(err)
		}
	}
	handoff := recipeHandoff{}
	handoff.Source.Base = "HEAD"
	handoff.Scope.Creates = []string{"allowed.txt"}
	if err := os.WriteFile(filepath.Join(lease.Workspace, "allowed.txt"), []byte("result"), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := recipeScopeDigest(context.Background(), lease, handoff); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(lease.Workspace, "outside.txt"), []byte("bad"), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := recipeScopeDigest(context.Background(), lease, handoff); err == nil {
		t.Fatal("scope escape accepted")
	}
}

func TestRecipeUsageRemainsReported(t *testing.T) {
	if recipeUsage("no measurement") != nil {
		t.Fatal("missing usage became zero")
	}
	usage := recipeUsage(`{"type":"turn.completed","usage":{"input_tokens":12,"output_tokens":3},"total_cost_usd":0.02}`)
	if usage["input_tokens"] != float64(12) || usage["claim"] != "reported_by_harness" {
		t.Fatal(usage)
	}
}

func TestLeaseClaimsSerializeAcrossRuns(t *testing.T) {
	store, lease := recipeStore(t)
	tx, err := store.db.Begin()
	if err != nil {
		t.Fatal(err)
	}
	defer tx.Rollback()
	candidate := FrontierTask{TaskID: "other", TaskRevisionDigest: "other-revision", ClaimedPaths: []string{"independent.txt"}, ClaimedResources: []string{"database"}}
	if err = checkLeaseClaims(tx, candidate); err == nil {
		t.Fatal("pre-upgrade unknown scope was ignored")
	}
	for _, claim := range [][2]string{{"marker", "v1"}, {"resource", "database"}, {"path", "src"}} {
		if _, err = tx.Exec("INSERT INTO lease_claims(attempt_id,kind,value) VALUES (?,?,?)", lease.AttemptID, claim[0], claim[1]); err != nil {
			t.Fatal(err)
		}
	}
	if err = checkLeaseClaims(tx, candidate); err == nil || !strings.Contains(err.Error(), "RESOURCE_LEASE_CONFLICT") {
		t.Fatalf("resource contention ignored: %v", err)
	}
	candidate.ClaimedResources = nil
	candidate.ClaimedPaths = []string{"src/child/file.go"}
	if err = checkLeaseClaims(tx, candidate); err == nil || !strings.Contains(err.Error(), "WRITE_LEASE_CONFLICT") {
		t.Fatalf("write contention ignored: %v", err)
	}
	if _, err = tx.Exec("UPDATE leases SET state='cancelled'"); err != nil {
		t.Fatal(err)
	}
	if err = checkLeaseClaims(tx, candidate); err != nil {
		t.Fatal("cancelled lease retained claims", err)
	}
}

func TestManagedRecipeCapabilityModes(t *testing.T) {
	for _, modes := range [][]string{{"supervised", "autonomous"}, {"autonomous"}} {
		probe := ProbeAdapter(AdapterDefinition{Name: "missing-test-adapter", Executable: "taskspec-nonexistent-probe", AssuranceModes: modes})
		if contains(modes, "supervised") {
			if len(probe.ManagedRecipeModes) != 1 || probe.ManagedRecipeModes[0] != "supervised" {
				t.Fatalf("recipe modes overstate assurance: %v", probe.ManagedRecipeModes)
			}
		} else if len(probe.ManagedRecipeModes) != 0 || len(probe.ManagedRecipeCapabilities) != 0 {
			t.Fatal("autonomous-only adapter advertised managed recipes")
		}
	}
}

func TestCredentialRotationPreservesHistoryAndMigratesV39(t *testing.T) {
	store, lease := recipeStore(t)
	lease.ExpiresAt = time.Now().Add(time.Hour).UTC().Format(time.RFC3339Nano)
	first, _, err := store.issueCredential(lease, "test", "fixed-model", "http://127.0.0.1")
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err = store.issueCredential(lease, "test", "fixed-model", "http://127.0.0.1"); err == nil {
		t.Fatal("issued two live capabilities for one attempt")
	}
	store.setCredentialState(lease.AttemptID, "revoked")
	// Reconstruct the previously shipped table before reopening the store.
	var schema string
	if err = store.db.QueryRow("SELECT sql FROM sqlite_master WHERE name='credential_leases'").Scan(&schema); err != nil {
		t.Fatal(err)
	}
	tx, err := store.db.Begin()
	if err != nil {
		t.Fatal(err)
	}
	for _, statement := range []string{
		"DROP INDEX one_active_credential",
		"ALTER TABLE credential_leases RENAME TO fixture_credentials",
		strings.Replace(schema, "NOT NULL REFERENCES", "NOT NULL UNIQUE REFERENCES", 1),
		"INSERT INTO credential_leases SELECT * FROM fixture_credentials",
		"DROP TABLE fixture_credentials",
	} {
		if _, err = tx.Exec(statement); err != nil {
			tx.Rollback()
			t.Fatal(err)
		}
	}
	if err = tx.Commit(); err != nil {
		t.Fatal(err)
	}
	repository := store.repository
	store.Close()
	reopened, err := OpenStore(repository)
	if err != nil {
		t.Fatal(err)
	}
	defer reopened.Close()
	second, _, err := reopened.issueCredential(lease, "test", "fixed-model", "http://127.0.0.1")
	if err != nil || first.LeaseID == second.LeaseID {
		t.Fatalf("rotation: %v", err)
	}
	reopened.setCredentialState(lease.AttemptID, "active")
	var oldState, newState string
	reopened.db.QueryRow("SELECT state FROM credential_leases WHERE lease_id=?", first.LeaseID).Scan(&oldState)
	reopened.db.QueryRow("SELECT state FROM credential_leases WHERE lease_id=?", second.LeaseID).Scan(&newState)
	if oldState != "revoked" || newState != "active" {
		t.Fatalf("history changed: %s %s", oldState, newState)
	}
	reopened.setCredentialState(lease.AttemptID, "revoked")
}

func TestAttestedRecipeCapabilityIsRestrictedToOMP(t *testing.T) {
	for _, name := range []string{"omp-rpc", "custom-sandbox"} {
		probe := ProbeAdapter(AdapterDefinition{Name: name, Executable: "taskspec-nonexistent-probe", AssuranceModes: []string{"supervised", "autonomous"}})
		if contains(probe.ManagedRecipeModes, "autonomous") != (name == "omp-rpc") {
			t.Fatalf("wrong attested capability for %s: %v", name, probe.ManagedRecipeModes)
		}
	}
}
