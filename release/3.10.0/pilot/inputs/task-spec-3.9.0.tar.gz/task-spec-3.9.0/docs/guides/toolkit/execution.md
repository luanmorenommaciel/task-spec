# Execute and recover with TaskMesh

Inspect `taskspec status <task>`, `taskspec mesh frontier`, and
`taskspec mesh explain --task <id>`. Ready leaves need a valid HMAC seal.
Use `taskspec mesh run --initiative <id> --execute` for the eligible native
initiative frontier, or `mesh run --task <id> --execute` for one managed task.
Declared resources and overlapping writes share the existing concurrency logic.
A run starts the currently eligible wave; inspect status before requesting later work.

A recipe-managed run follows existing attempts, worktrees, leases, fencing,
cancellation, and recovery. Per-round artifacts retain executor and eval evidence;
no separate loop runner is introduced. In supervised mode, passing evals enter
awaiting_supervision.
Use `mesh accept <attempt> --supervised-by <identity> --reason <text>` only with
applicable supervisor authorization. `finish` reports the human integration route.

After interruption, read `mesh status`, `mesh watch <run>`, and initiative state.
Use `mesh resume <run-or-attempt> --execute` only after resolving the recorded blocker.
Resuming does not refund recipe rounds or restart its total deadline. Exhaustion
requires reviewed successor work, not silent budget expansion.

Ordinary tasks retain direct `taskspec handoff`. Managed recipes require TaskMesh.
Supervised adapters and the attested OMP sandbox use the same round controller.
Autonomous OMP requires the pinned sandbox, fixed provider/model, external host
attestor, and evaluator trust registry. Each round receives a fresh expiring
capability and retains its own signed execution evidence; prior credentials stay
revoked. Evals run in the sanitized host environment, and canonical acceptance
reruns the task proof. Execution attestation does not claim eval isolation.
Custom required environment contracts and hard token limits refuse before any
round when their enforcement cannot be established. No silent downgrade occurs.

Keep the authorized task, native plan bundle, immutable snapshots, and applicable
source evidence in the Git revision used for the attempt. Mesh creates worktrees
from that revision. Recording files in Git does not replace review or HMAC sealing.

Round evidence distinguishes explicitly routed models from models reported by a
harness. Unreported defaults remain unknown; comparative qualification requires
explicit model and provider identities. Supervised adapters use the harness host
environment; required isolation or hard token enforcement must refuse if unavailable.

Recipe-managed Claude runs with no declared MCP dependencies use restricted
Read/Edit/Write/Bash tools and an empty MCP configuration. User, project, and
local settings hooks are excluded from that worker context; managed host policy
still applies. Explicit route model/provider choices remain authoritative.
Declare needed MCP dependencies or provide an explicitly configured adapter.
