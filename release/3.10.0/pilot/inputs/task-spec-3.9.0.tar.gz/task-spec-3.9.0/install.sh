#!/usr/bin/env bash
# Install a pinned Task-Spec engine, CLI launcher, and equivalent harness skills.
set -euo pipefail

PINNED_VERSION="3.9.0"
REPOSITORY="luanmorenommaciel/task-spec"
TARGET="$PWD"
MODE="copy"
BIN_DIR="${HOME}/.local/bin"
NO_BIN=false
FORCE=false
WITH_MESH=false
TOOLKIT=false
DRY_RUN=false

usage() {
  cat <<'EOF'
Usage: install.sh [options]
  --global           install user-level skills for Codex/Kimi, Claude, Grok, and Cursor
  --target DIR       repository receiving harness skills (default: PWD)
  --copy             pinned copy installation (default)
  --symlink          checkout-development mode; source must be a local checkout
  --bin-dir DIR      CLI launcher directory (default: ~/.local/bin)
  --no-bin           install skills only
  --with-mesh        install the matching optional TaskMesh helper
  --toolkit          install CLI, private decomposition runtime, skills, and TaskMesh
  --dry-run          print installation destinations without writing
  --force            back up and replace existing managed destinations
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --global)
      [[ -n "${HOME:-}" ]] || { echo "install.sh: HOME is required for --global" >&2; exit 2; }
      TARGET="$HOME"
      shift
      ;;
    --target) TARGET="${2:-}"; shift 2 ;;
    --target=*) TARGET="${1#*=}"; shift ;;
    --copy) MODE="copy"; shift ;;
    --symlink) MODE="symlink"; shift ;;
    --bin-dir) BIN_DIR="${2:-}"; shift 2 ;;
    --bin-dir=*) BIN_DIR="${1#*=}"; shift ;;
    --no-bin) NO_BIN=true; shift ;;
    --with-mesh) WITH_MESH=true; shift ;;
    --toolkit) TOOLKIT=true; WITH_MESH=true; shift ;;
    --dry-run) DRY_RUN=true; shift ;;
    --force) FORCE=true; shift ;;
    --help|-h) usage; exit 0 ;;
    --version) echo "$PINNED_VERSION"; exit 0 ;;
    *) echo "install.sh: unknown option $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [[ "$WITH_MESH" == true && "$NO_BIN" == true ]]; then
  echo "install.sh: --with-mesh requires the CLI; remove --no-bin" >&2
  exit 2
fi

[[ -d "$TARGET" ]] || { echo "install.sh: target directory does not exist: $TARGET" >&2; exit 2; }
TARGET="$(cd "$TARGET" && pwd)"

installer_source="${BASH_SOURCE[0]}"
while [[ -h "$installer_source" ]]; do
  installer_dir="$(cd -P "$(dirname "$installer_source")" >/dev/null 2>&1 && pwd)"
  installer_source="$(readlink "$installer_source")"
  [[ "$installer_source" != /* ]] && installer_source="$installer_dir/$installer_source"
done
SCRIPT_DIR="$(cd -P "$(dirname "$installer_source")" 2>/dev/null && pwd || true)"
unset installer_source installer_dir
SOURCE_ROOT=""
DOWNLOAD_DIR=""
if [[ -n "$SCRIPT_DIR" && -f "$SCRIPT_DIR/VERSION" && -x "$SCRIPT_DIR/bin/taskspec" ]]; then
  SOURCE_ROOT="$SCRIPT_DIR"
else
  [[ "$MODE" != "symlink" ]] || { echo "install.sh: --symlink requires a local Task-Spec checkout" >&2; exit 2; }
  command -v curl >/dev/null 2>&1 || { echo "install.sh: curl is required for remote installation" >&2; exit 2; }
  command -v tar >/dev/null 2>&1 || { echo "install.sh: tar is required for remote installation" >&2; exit 2; }
  DOWNLOAD_DIR="$(mktemp -d -t taskspec-install-XXXXXX)"
  trap '[[ -n "$DOWNLOAD_DIR" ]] && rm -rf "$DOWNLOAD_DIR"' EXIT
  archive="$DOWNLOAD_DIR/task-spec.tar.gz"
  checksum="$DOWNLOAD_DIR/task-spec.tar.gz.sha256"
  release_base="${TASKSPEC_RELEASE_BASE_URL:-https://github.com/$REPOSITORY/releases/download/v$PINNED_VERSION}"
  asset_name="task-spec-$PINNED_VERSION.tar.gz"
  curl -fsSL "$release_base/$asset_name" -o "$archive"
  curl -fsSL "$release_base/$asset_name.sha256" -o "$checksum"
  expected_sha="$(awk 'NR == 1 {print $1}' "$checksum")"
  case "$expected_sha" in
    *[!0-9a-f]*|'') echo "install.sh: invalid release checksum manifest" >&2; exit 1 ;;
  esac
  if command -v shasum >/dev/null 2>&1; then
    actual_sha="$(shasum -a 256 "$archive" | awk '{print $1}')"
  elif command -v sha256sum >/dev/null 2>&1; then
    actual_sha="$(sha256sum "$archive" | awk '{print $1}')"
  elif command -v openssl >/dev/null 2>&1; then
    actual_sha="$(openssl dgst -sha256 "$archive" | awk '{print $NF}')"
  else
    echo "install.sh: SHA-256 provider required to verify the immutable release archive" >&2
    exit 2
  fi
  [[ "$actual_sha" == "$expected_sha" ]] || { echo "install.sh: release archive checksum mismatch" >&2; exit 1; }
  echo "verified: release archive sha256:$actual_sha"
  tar -xzf "$archive" -C "$DOWNLOAD_DIR"
  SOURCE_ROOT="$DOWNLOAD_DIR/task-spec-$PINNED_VERSION"
fi

SOURCE_VERSION="$(tr -d '[:space:]' < "$SOURCE_ROOT/VERSION")"
[[ "$SOURCE_VERSION" == "$PINNED_VERSION" ]] || { echo "install.sh: expected v$PINNED_VERSION, source is v$SOURCE_VERSION" >&2; exit 1; }

if [[ "$DRY_RUN" == true ]]; then
  printf 'INSTALL=DRY_RUN target=%s engine=%s bin=%s toolkit=%s mesh=%s\n' "$TARGET" "${TASKSPEC_INSTALL_ROOT:-${HOME}/.local/share/task-spec}/$PINNED_VERSION" "$BIN_DIR" "$TOOLKIT" "$WITH_MESH"
  exit 0
fi

backup_existing() {
  local path="$1"
  if [[ -e "$path" || -L "$path" ]]; then
    if [[ "$FORCE" != true ]]; then
      echo "install.sh: refusing to clobber existing $path (use --force)" >&2
      return 1
    fi
    backup="${path}.backup.$(date -u +%Y%m%dT%H%M%SZ)"
    mv "$path" "$backup"
    echo "backup: $backup"
  fi
}

resolve_existing_file() {
  local value="$1" directory target
  while [[ -L "$value" ]]; do
    directory="$(cd -P "$(dirname "$value")" >/dev/null 2>&1 && pwd)"
    target="$(readlink "$value")"
    if [[ "$target" == /* ]]; then value="$target"; else value="$directory/$target"; fi
  done
  directory="$(cd -P "$(dirname "$value")" >/dev/null 2>&1 && pwd)"
  printf '%s/%s\n' "$directory" "$(basename "$value")"
}

INSTALL_ROOT="${TASKSPEC_INSTALL_ROOT:-${HOME}/.local/share/task-spec}"
ENGINE_DEST="$INSTALL_ROOT/$PINNED_VERSION"
if [[ "$MODE" == "symlink" ]]; then
  if [[ -e "$ENGINE_DEST" || -L "$ENGINE_DEST" ]]; then
    if [[ -L "$ENGINE_DEST" && "$(readlink "$ENGINE_DEST")" == "$SOURCE_ROOT" ]]; then
      echo "kept: engine symlink $ENGINE_DEST"
    else
      backup_existing "$ENGINE_DEST"
      mkdir -p "$(dirname "$ENGINE_DEST")"
      ln -s "$SOURCE_ROOT" "$ENGINE_DEST"
    fi
  else
    mkdir -p "$(dirname "$ENGINE_DEST")"
    ln -s "$SOURCE_ROOT" "$ENGINE_DEST"
  fi
else
  if [[ -f "$ENGINE_DEST/VERSION" && "$(tr -d '[:space:]' < "$ENGINE_DEST/VERSION")" == "$PINNED_VERSION" && "$FORCE" != true ]]; then
    python3 "$SOURCE_ROOT/tools/verify-toolkit.py" --engine "$ENGINE_DEST" --source "$SOURCE_ROOT" >/dev/null
    echo "kept: pinned engine $ENGINE_DEST"
  else
    [[ ! -e "$ENGINE_DEST" ]] || backup_existing "$ENGINE_DEST"
    mkdir -p "$ENGINE_DEST"
    for item in VERSION LICENSE README.md CHANGELOG.md SKILL.md assets bin harness src spec docs tools .claude-plugin; do
      [[ -e "$SOURCE_ROOT/$item" ]] && cp -R "$SOURCE_ROOT/$item" "$ENGINE_DEST/$item"
    done
    # Conformance executions create local state; it is never a shipped resource.
    rm -rf "$ENGINE_DEST/spec/conformance/_workdir" \
      "$ENGINE_DEST/spec/conformance/_state.yaml" "$ENGINE_DEST/spec/conformance/results.json"
    if [[ -d "$SOURCE_ROOT/release/mesh" ]]; then
      mkdir -p "$ENGINE_DEST/release"
      cp -R "$SOURCE_ROOT/release/mesh" "$ENGINE_DEST/release/mesh"
    fi
    echo "engine: $ENGINE_DEST"
  fi
fi

sha256_file() {
  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$1" | awk '{print $1}'
  elif command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" | awk '{print $1}'
  elif command -v openssl >/dev/null 2>&1; then
    openssl dgst -sha256 "$1" | awk '{print $NF}'
  else
    echo "install.sh: SHA-256 provider required for TaskMesh" >&2
    return 2
  fi
}

install_mesh() {
  local kernel machine platform asset asset_path checksum_path expected_sha actual_sha mesh_tmp
  kernel="$(uname -s)"
  machine="$(uname -m)"
  case "$kernel" in
    Darwin) platform="darwin" ;;
    Linux) platform="linux" ;;
    *) echo "install.sh: TaskMesh has no helper for $kernel" >&2; return 2 ;;
  esac
  case "$machine" in
    x86_64|amd64) machine="amd64" ;;
    arm64|aarch64) machine="arm64" ;;
    *) echo "install.sh: TaskMesh has no helper for $machine" >&2; return 2 ;;
  esac
  asset="taskspec-meshd-$platform-$machine"
  asset_path=""
  for candidate in \
    "${TASKSPEC_MESH_ASSET_DIR:-}/$asset" \
    "$SOURCE_ROOT/release/$PINNED_VERSION/bin/$asset" \
    "$(dirname "$SOURCE_ROOT")/$asset" \
    "$SCRIPT_DIR/$asset"; do
    if [[ "$candidate" != "/$asset" && -f "$candidate" ]]; then
      asset_path="$candidate"
      break
    fi
  done

  if [[ -z "$asset_path" && -f "$SOURCE_ROOT/go.mod" && -d "$SOURCE_ROOT/mesh/cmd/taskspec-meshd" ]]; then
    command -v go >/dev/null 2>&1 || {
      echo "install.sh: Go is required to build TaskMesh from a checkout; provide a release helper asset instead" >&2
      return 2
    }
    mesh_tmp="$(mktemp -d -t taskspec-mesh-build-XXXXXX)"
    (cd "$SOURCE_ROOT" && CGO_ENABLED=0 go build -trimpath -ldflags='-s -w' -o "$mesh_tmp/$asset" ./mesh/cmd/taskspec-meshd)
    asset_path="$mesh_tmp/$asset"
    checksum_path=""
  elif [[ -n "$asset_path" ]]; then
    checksum_path="$asset_path.sha256"
    [[ -f "$checksum_path" ]] || {
      echo "install.sh: missing TaskMesh checksum: $checksum_path" >&2
      return 1
    }
  else
    command -v curl >/dev/null 2>&1 || { echo "install.sh: curl is required to download TaskMesh" >&2; return 2; }
    mesh_tmp="$(mktemp -d -t taskspec-mesh-download-XXXXXX)"
    release_base="${TASKSPEC_RELEASE_BASE_URL:-https://github.com/$REPOSITORY/releases/download/v$PINNED_VERSION}"
    curl -fsSL "$release_base/$asset" -o "$mesh_tmp/$asset"
    curl -fsSL "$release_base/$asset.sha256" -o "$mesh_tmp/$asset.sha256"
    asset_path="$mesh_tmp/$asset"
    checksum_path="$mesh_tmp/$asset.sha256"
  fi

  if [[ -n "${checksum_path:-}" ]]; then
    expected_sha="$(awk 'NR == 1 {print $1}' "$checksum_path")"
    case "$expected_sha" in
      *[!0-9a-f]*|'') echo "install.sh: invalid TaskMesh checksum manifest" >&2; return 1 ;;
    esac
    actual_sha="$(sha256_file "$asset_path")"
    [[ "$actual_sha" == "$expected_sha" ]] || { echo "install.sh: TaskMesh checksum mismatch" >&2; return 1; }
    echo "verified: TaskMesh sha256:$actual_sha"
  fi

  mkdir -p "$BIN_DIR"
  if [[ "$MODE" != "symlink" ]]; then
    mkdir -p "$ENGINE_DEST/libexec"
    cp "$asset_path" "$ENGINE_DEST/libexec/.taskspec-meshd.tmp"
    chmod 0755 "$ENGINE_DEST/libexec/.taskspec-meshd.tmp"
    mv "$ENGINE_DEST/libexec/.taskspec-meshd.tmp" "$ENGINE_DEST/libexec/taskspec-meshd"
  fi
  cp "$asset_path" "$BIN_DIR/.taskspec-meshd.tmp"
  chmod 0755 "$BIN_DIR/.taskspec-meshd.tmp"
  mv "$BIN_DIR/.taskspec-meshd.tmp" "$BIN_DIR/taskspec-meshd"
  "$BIN_DIR/taskspec-meshd" --version-json | python3 -c \
    'import json,sys; v=json.load(sys.stdin); assert v["contract"] == "TaskMeshAPI/v1alpha1" and v["product_version"] == sys.argv[1]' \
    "$PINNED_VERSION" || { echo "install.sh: TaskMesh helper failed its version check" >&2; return 1; }
  echo "mesh:   $BIN_DIR/taskspec-meshd"
  [[ -z "${mesh_tmp:-}" ]] || rm -rf "$mesh_tmp"
}

if [[ "$WITH_MESH" == true ]]; then
  install_mesh
fi
if [[ "$TOOLKIT" == true ]]; then
  python3 "$ENGINE_DEST/src/setup/decompose.py"
fi

install_skill_copy() {
  local destination="$1"
  if [[ -e "$destination" || -L "$destination" ]]; then
    if [[ -f "$destination/.taskspec-version" && "$(cat "$destination/.taskspec-version")" == "$PINNED_VERSION" && "$FORCE" != true ]]; then
      local guides_match=true guide
      for guide in "$SOURCE_ROOT/docs/guides/toolkit/"*.md; do
        cmp -s "$guide" "$destination/docs/guides/toolkit/$(basename "$guide")" || guides_match=false
      done
      if [[ "$guides_match" == true ]] && cmp -s "$SOURCE_ROOT/SKILL.md" "$destination/SKILL.md"; then
        echo "kept: $destination"
        return 0
      fi
    fi
    backup_existing "$destination" || return 1
  fi
  mkdir -p "$destination/references/schemas" "$destination/references/concepts"
  cp "$SOURCE_ROOT/SKILL.md" "$destination/SKILL.md"
  mkdir -p "$destination/docs/guides/toolkit"
  cp "$SOURCE_ROOT/docs/guides/toolkit/"*.md "$destination/docs/guides/toolkit/"
  cp "$SOURCE_ROOT/docs/authoring-workflow.md" "$destination/references/authoring-workflow.md"
  cp "$SOURCE_ROOT/docs/quick-reference.md" "$destination/references/quick-reference.md"
  cp "$SOURCE_ROOT/docs/concepts/effort-gate.md" "$destination/references/concepts/effort-gate.md"
  cp "$SOURCE_ROOT/docs/concepts/signed-off.md" "$destination/references/concepts/signed-off.md"
  cp "$SOURCE_ROOT/spec/schemas/"*.json "$destination/references/schemas/"
  printf '%s\n' "$PINNED_VERSION" > "$destination/.taskspec-version"
  echo "skill:  $destination"
}

install_skill_link() {
  local destination="$1"
  if [[ -L "$destination" && "$(readlink "$destination")" == "$SOURCE_ROOT" ]]; then echo "kept: $destination"; return 0; fi
  [[ ! -e "$destination" && ! -L "$destination" ]] || backup_existing "$destination" || return 1
  mkdir -p "$(dirname "$destination")"
  ln -s "$SOURCE_ROOT" "$destination"
  echo "skill:  $destination -> $SOURCE_ROOT"
}

for destination in \
  "$TARGET/.agents/skills/task-spec" \
  "$TARGET/.claude/skills/task-spec" \
  "$TARGET/.grok/skills/task-spec" \
  "$TARGET/.cursor/skills/task-spec"; do
  if [[ "$MODE" == "symlink" ]]; then install_skill_link "$destination"; else install_skill_copy "$destination"; fi
done

# Preserve the legacy Claude subagent entrypoint alongside the portable skill.
# The skill is the canonical authoring surface; this file is a compatibility
# door for existing checkouts and prompts that invoke `task-architect` directly.
architect_destination="$TARGET/.claude/agents/task-architect.md"
if [[ "$MODE" == "symlink" ]]; then
  if [[ -L "$architect_destination" && "$(readlink "$architect_destination")" == "$SOURCE_ROOT/harness/agents/task-architect.md" ]]; then
    echo "kept: $architect_destination"
  else
    [[ ! -e "$architect_destination" && ! -L "$architect_destination" ]] || backup_existing "$architect_destination"
    mkdir -p "$(dirname "$architect_destination")"
    ln -s "$SOURCE_ROOT/harness/agents/task-architect.md" "$architect_destination"
    echo "agent:  $architect_destination -> $SOURCE_ROOT/harness/agents/task-architect.md"
  fi
else
  if [[ -f "$architect_destination" ]] && cmp -s "$SOURCE_ROOT/harness/agents/task-architect.md" "$architect_destination" && [[ "$FORCE" != true ]]; then
    echo "kept: $architect_destination"
  else
    [[ ! -e "$architect_destination" && ! -L "$architect_destination" ]] || backup_existing "$architect_destination"
    mkdir -p "$(dirname "$architect_destination")"
    cp "$SOURCE_ROOT/harness/agents/task-architect.md" "$architect_destination"
    echo "agent:  $architect_destination"
  fi
fi

if [[ "$NO_BIN" != true ]]; then
  mkdir -p "$BIN_DIR"
  launcher="$BIN_DIR/taskspec"
  if [[ -e "$launcher" || -L "$launcher" ]]; then
    if grep -q "task-spec launcher v$PINNED_VERSION" "$launcher" 2>/dev/null && [[ "$FORCE" != true ]]; then
      echo "kept: CLI launcher $launcher"
    elif [[ -x "$launcher" && -x "$SOURCE_ROOT/bin/taskspec" ]] \
      && [[ "$(resolve_existing_file "$launcher")" == "$(resolve_existing_file "$SOURCE_ROOT/bin/taskspec")" ]] \
      && [[ "$("$launcher" version)" == "$PINNED_VERSION" ]] \
      && [[ "$FORCE" != true ]]; then
      # npm already placed the exact package CLI in BIN_DIR. Keep that link;
      # taskspec-install still installs the pinned engine, skills, and optional
      # TaskMesh helper without asking to overwrite its own package entrypoint.
      echo "kept: package CLI $launcher"
    elif grep -qE '^# task-spec launcher v[0-9]+\.[0-9]+\.[0-9]+$' "$launcher" 2>/dev/null && [[ "$FORCE" != true ]]; then
      # This is a launcher previously managed by Task-Spec, not an arbitrary
      # user executable. A version upgrade may safely repoint it to the new
      # side-by-side pinned engine without requiring destructive --force.
      printf '%s\n' '#!/usr/bin/env sh' "# task-spec launcher v$PINNED_VERSION" "exec \"$ENGINE_DEST/bin/taskspec\" \"\$@\"" > "$launcher"
      chmod +x "$launcher"
      echo "updated: CLI launcher $launcher"
    else
      backup_existing "$launcher"
    fi
  fi
  if [[ ! -e "$launcher" && ! -L "$launcher" ]]; then
    printf '%s\n' '#!/usr/bin/env sh' "# task-spec launcher v$PINNED_VERSION" "exec \"$ENGINE_DEST/bin/taskspec\" \"\$@\"" > "$launcher"
    chmod +x "$launcher"
    echo "cli:    $launcher"
  fi
  case ":$PATH:" in *":$BIN_DIR:"*) ;; *) echo "note: add $BIN_DIR to PATH" ;; esac
fi

for destination in "$TARGET/.agents/skills/task-spec" "$TARGET/.claude/skills/task-spec" "$TARGET/.grok/skills/task-spec" "$TARGET/.cursor/skills/task-spec"; do
  [[ -r "$destination/SKILL.md" ]] || { echo "install.sh: missing installed skill at $destination" >&2; exit 1; }
  grep -q '^name: task-spec$' "$destination/SKILL.md" || { echo "install.sh: invalid skill at $destination" >&2; exit 1; }
done
[[ -x "$ENGINE_DEST/bin/taskspec" ]] || { echo "install.sh: installed engine CLI is not executable" >&2; exit 1; }
[[ "$("$ENGINE_DEST/bin/taskspec" version)" == "$PINNED_VERSION" ]] || { echo "install.sh: installed engine failed its version check" >&2; exit 1; }
for destination in "$TARGET/.agents/skills/task-spec" "$TARGET/.claude/skills/task-spec" "$TARGET/.grok/skills/task-spec" "$TARGET/.cursor/skills/task-spec"; do
  cmp -s "$SOURCE_ROOT/SKILL.md" "$destination/SKILL.md" || { echo "install.sh: installed skill differs at $destination" >&2; exit 1; }
done
if [[ "$NO_BIN" != true ]]; then
  [[ "$("$launcher" version)" == "$PINNED_VERSION" ]] || { echo "install.sh: CLI launcher failed its version check" >&2; exit 1; }
fi

echo "Credentials: unchanged (Task-Spec never installs provider or model secrets)."
if [[ "$NO_BIN" != true ]]; then
  case ":$PATH:" in
    *":$BIN_DIR:"*) ;;
    *) echo "PATH: add $BIN_DIR, then enable completion with: taskspec completion bash|zsh|fish" ;;
  esac
fi
echo "Verify: taskspec doctor"
echo "Prove:  taskspec demo"
if [[ "$WITH_MESH" == true ]]; then
  echo "Mesh:   taskspec mesh doctor"
fi
verify_args=(--engine "$ENGINE_DEST" --source "$SOURCE_ROOT" --target "$TARGET" --quiet)
if [[ "$TOOLKIT" == true ]]; then verify_args+=(--runtime --helper "$BIN_DIR/taskspec-meshd"); fi
python3 "$SOURCE_ROOT/tools/verify-toolkit.py" "${verify_args[@]}"
echo "INSTALL=OK"
