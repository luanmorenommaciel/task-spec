#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d -t 'toolkit-install-XXXXXX')"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/project with spaces"
TASKSPEC_INSTALL_ROOT="$TMP/engines" bash "$ROOT/install.sh" --toolkit --target "$TMP/project with spaces" --bin-dir "$TMP/bin with spaces" > "$TMP/install.log" 2>&1 || { cat "$TMP/install.log"; exit 1; }
"$TMP/bin with spaces/taskspec" --json guide decomposition > "$TMP/guide.json"
version="$(cat "$ROOT/VERSION")"
TASKSPEC_TEST_CLI="$TMP/bin with spaces/taskspec" \
TASKSPEC_DECOMPOSE_PYTHON="$TMP/engines/$version/.taskspec/runtime/decompose/bin/python" \
  bash "$ROOT/tests/test-toolkit-decompose.sh"
python3 - "$ROOT" "$TMP" <<'PY'
from pathlib import Path
import json,subprocess,sys
root,temp=map(Path,sys.argv[1:]);version=(root/'VERSION').read_text().strip();engine=temp/'engines'/version
assert json.loads((temp/'guide.json').read_text())['data']['version']==version
runtime=engine/'.taskspec/runtime/decompose/bin/python';assert runtime.is_file()
subprocess.run([str(runtime),'-c','import yaml,jsonschema'],check=True)
# A matching dependency lock alone cannot certify a prior engine's runtime.
receipt=engine/'.taskspec/runtime/decompose/taskspec-runtime.json'
identity=json.loads(receipt.read_text());identity['version']='0.0.0-old';receipt.write_text(json.dumps(identity)+'\n')
subprocess.run(['bash',str(engine/'bin/taskspec'),'setup','decompose'],check=True,capture_output=True)
assert json.loads(receipt.read_text())['version']==version
verify=[sys.executable,str(root/'tools/verify-toolkit.py'),'--engine',str(engine),'--source',str(root)]
for relative in ('spec/conformance/results.json','spec/conformance/_state.yaml','spec/conformance/_workdir'):
 assert not (engine/relative).exists(),relative+' was shipped as a resource'
# Running conformance after installation must not look like runtime code drift.
(engine/'spec/conformance/results.json').write_text('{"generated":true}')
(engine/'spec/conformance/_state.yaml').write_text('generated: true')
(engine/'spec/conformance/_workdir').mkdir()
(engine/'spec/conformance/_workdir/runtime.json').write_text('{}')
assert subprocess.run(verify,capture_output=True).returncode==0
code=engine/'src/recipe/recipes.py';original=code.read_bytes();code.write_bytes(original+b'\n# modified after install\n')
assert subprocess.run(verify,capture_output=True).returncode!=0
code.write_bytes(original)
extra=engine/'src/recipe/unexpected.py';extra.write_text('unregistered runtime input')
assert subprocess.run(verify,capture_output=True).returncode!=0
extra.unlink()
source=temp/'project with spaces/.agents/skills/task-spec/docs/guides/toolkit/decomposition.md';source.write_text('corrupted installation')
result=subprocess.run([sys.executable,str(root/'tools/verify-toolkit.py'),'--engine',str(engine),'--source',str(root),'--target',str(temp/'project with spaces'),'--runtime'],capture_output=True)
assert result.returncode!=0
print('TOOLKIT_INSTALL=PASS clean private runtime, path spaces, version identity, and corrupted-resource refusal')
PY
